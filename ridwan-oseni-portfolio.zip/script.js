const filters = document.querySelector('.filters');
const cards = Array.from(document.querySelectorAll('.project-card'));
const status = document.querySelector('#filter-status');

function filterProjects(category) {
  let visible = 0;
  for (const card of cards) {
    card.hidden = category !== 'all' && card.dataset.category !== category;
    if (!card.hidden) visible += 1;
  }
  for (const button of filters.querySelectorAll('button')) {
    button.setAttribute('aria-pressed', String(button.dataset.filter === category));
  }
  status.textContent = visible === 1 ? '1 project shown' : `${visible} projects shown`;
}

filters.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-filter]');
  if (button) filterProjects(button.dataset.filter);
});
filters.hidden = false;

const dialog = document.querySelector('#case-dialog');
const content = document.querySelector('#dialog-content');
const closeButton = document.querySelector('#close-case');
let activeCase;
let originalPosition;
let openingLink;

function showCase(caseFile, link) {
  openingLink = link;
  activeCase = caseFile;
  originalPosition = document.createComment('Case study position');
  caseFile.before(originalPosition);
  content.append(caseFile);
  dialog.setAttribute('aria-labelledby', caseFile.querySelector('h2').id);
  dialog.showModal();
  dialog.scrollTop = 0;
  closeButton.focus();
}

if (typeof dialog.showModal === 'function') {
  document.addEventListener('click', (event) => {
    const link = event.target.closest('.case-link');
    if (!link || event.defaultPrevented || event.button !== 0 ||
        event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const caseFile = document.getElementById(link.hash.slice(1));
    if (!caseFile?.classList.contains('case-file')) return;
    event.preventDefault();
    showCase(caseFile, link);
  });

  closeButton.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) {
      const rect = dialog.getBoundingClientRect();
      const outside = event.clientX < rect.left || event.clientX > rect.right ||
        event.clientY < rect.top || event.clientY > rect.bottom;
      if (outside) dialog.close();
    }
  });
  dialog.addEventListener('close', () => {
    originalPosition.replaceWith(activeCase);
    openingLink.focus({ preventScroll: true });
  });
}
